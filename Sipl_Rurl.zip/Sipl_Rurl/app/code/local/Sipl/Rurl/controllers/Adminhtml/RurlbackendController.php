<?php
class Sipl_Rurl_Adminhtml_RurlbackendController extends Mage_Adminhtml_Controller_Action
{
	 
    
    
    public function indexAction()
    {  
		$this->loadLayout();
		$block = $this->getLayout()->createBlock('sipl_rurl/adminhtml_rurlbackend','test_form');
		$this->getLayout()->getBlock('content')->append($block);
		$this->renderLayout();
    }

	public function newcsvAction()
    {    
		$post_data=$this->getRequest()->getPost();
		if($_FILES['csvfile']['name']){
		try {
		
		
		
		$uploader = new Varien_File_Uploader('csvfile');
		$uploader->setAllowedExtensions(array('csv','CSV')); // or pdf or anything
		$uploader->setAllowRenameFiles(false);
		$uploader->setFilesDispersion(false);
		$path = Mage::getBaseDir('var') . DS . 'csv';
		$uploader->save($path, $_FILES['csvfile']['name']);
		$data['csvfile'] = $_FILES['csvfile']['name'];
		$full_path = $path."/".$_FILES['csvfile']['name'];
		$csvObject = new Varien_File_Csv();
		$dataArray = $csvObject->getData($full_path);
		$model = Mage::getModel('rurl/rurl'); 
		
		$collection = Mage::getModel('rurl/rurl')->getCollection();
		foreach($dataArray as $data){
			//echo $data[0];die;   
			foreach($collection as $urls){
				//~ echo $data[0]  = rtrim($data[0],'/');die;
				//~ $urls['old_url']  = rtrim($urls['old_url'],'/');
				 
				if($data[0]  == $urls['old_url']){
				Mage::getSingleton("adminhtml/session")->addError(Mage::helper("adminhtml")->__("Old Url Already in grid"));
				$this->_redirect("*/*/");
				return;
				}else{
					$model->setData('old_url',$data[0]); 
					$model->setData('new_url',$data[1]); 
					$model->save(); 
					$model->unsetData();
					} 
			}
		
			  
		} 
		$this->_redirect("*/*/");
		Mage::getSingleton("adminhtml/session")->addSuccess(Mage::helper("adminhtml")->__("  Csv was successfully saved"));
						return;
		}catch(Exception $e) {
		Mage::getSingleton("adminhtml/session")->addError(Mage::helper("adminhtml")->__("Please Upload valid file"));
		$this->_redirect("*/*/");
		}
		}else{
		Mage::getSingleton("adminhtml/session")->addError(Mage::helper("adminhtml")->__("Please Upload valid file"));
		$this->_redirect("*/*/");
		} 
	
	
	
	
	
				
  }
    
}
