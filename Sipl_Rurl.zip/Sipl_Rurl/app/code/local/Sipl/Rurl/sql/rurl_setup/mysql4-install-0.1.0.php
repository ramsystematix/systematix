<?php
$installer = $this;
$installer->startSetup();
$sql=<<<SQLTEXT
create table rurl(id int not null auto_increment, old_url varchar(100), new_url varchar(100), primary key(id));
SQLTEXT;

$installer->run($sql);
//demo 
//Mage::getModel('core/url_rewrite')->setId(null);
//demo 
$installer->endSetup();
	 