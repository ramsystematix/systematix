<?php
    class Sipl_Rurl_Model_Mysql4_Rurl_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
    {

		public function _construct(){
			$this->_init("rurl/rurl");
		}

		

    }
	 