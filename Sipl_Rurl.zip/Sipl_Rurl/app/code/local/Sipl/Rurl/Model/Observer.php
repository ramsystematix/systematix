<?php
class Sipl_Rurl_Model_Observer
{ public function setcustomRedirect(Varien_Event_Observer $observer)
			{ 
				//
			$currentUrl = Mage::helper('core/url')->getCurrentUrl();
			$url = Mage::getSingleton('core/url')->parseUrl($currentUrl);
			$path = $url->getPath();
			$collection = Mage::getModel('rurl/rurl')->getCollection();
			
			foreach($collection as $urls){
				$currentUrl  = rtrim($currentUrl,'/');
				$urls['old_url']  = rtrim($urls['old_url'],'/');
				
				if($currentUrl  == $urls['old_url']){

					// if($_SERVER['REMOTE_ADDR'] == '183.182.84.76'){echo $urls['new_url'];die;}
				 // echo Mage::app()->getResponse()->setRedirect($urls['new_url']);exit;
				  echo Mage::app()->getResponse()->clearHeaders()->setRedirect($urls['new_url'], 301)->sendResponse();exit;
				break; 
				}	
			
			}
		}
}
