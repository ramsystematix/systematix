<?php


class Sipl_Rurl_Block_Adminhtml_Rurl extends Mage_Adminhtml_Block_Widget_Grid_Container{

	public function __construct()
	{

	$this->_controller = "adminhtml_rurl";
	$this->_blockGroup = "rurl";
	$this->_headerText = Mage::helper("rurl")->__("Custom Url Manager");
	$this->_addButtonLabel = Mage::helper("rurl")->__("Add New Url");
	parent::__construct();
	
	}

}
