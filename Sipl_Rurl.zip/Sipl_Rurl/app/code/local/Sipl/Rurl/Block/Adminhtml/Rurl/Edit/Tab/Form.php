<?php
class Sipl_Rurl_Block_Adminhtml_Rurl_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
		protected function _prepareForm()
		{

				$form = new Varien_Data_Form();
				$this->setForm($form);
				$fieldset = $form->addFieldset("rurl_form", array("legend"=>Mage::helper("rurl")->__("Item information")));
				
				
						$fieldset->addField("old_url", "text", array(
						"label" => Mage::helper("rurl")->__("Old Url"),
						"name" => "old_url",
						));
					
						$fieldset->addField("new_url", "text", array(
						"label" => Mage::helper("rurl")->__("New Url"),
						"name" => "new_url",
						));
					

				if (Mage::getSingleton("adminhtml/session")->getRurlData())
				{
					$form->setValues(Mage::getSingleton("adminhtml/session")->getRurlData());
					Mage::getSingleton("adminhtml/session")->setRurlData(null);
				} 
				elseif(Mage::registry("rurl_data")) {
				    $form->setValues(Mage::registry("rurl_data")->getData());
				}
				return parent::_prepareForm();
		}
}
