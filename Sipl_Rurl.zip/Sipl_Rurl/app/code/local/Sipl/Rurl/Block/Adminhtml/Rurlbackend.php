<?php  

class Sipl_Rurl_Block_Adminhtml_Rurlbackend extends Mage_Adminhtml_Block_Template {
public function __construct() {
    parent::__construct();
    $this->setTemplate('rurl/rurlbackend.phtml');
    $this->setFormAction(Mage::getUrl('*/*/newcsv'));
  }
  
  public function newcsvAction(){
	  }
}
